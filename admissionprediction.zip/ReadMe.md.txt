This dataset is created for prediction of graduate admissions and the dataset link is below: 

https://www.kaggle.com/mohansacharya/graduate-admissions 